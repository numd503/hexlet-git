def main():
    print("Hellow, fellow kids!")

if __name__ == '__main__':
    main()
